from lstore.virtualPage import *
from lstore.table import *

class tailPage(virtualPage):

   def __init__(self, page_id, num_columns):
      super().__init__(page_id, num_columns)
      pass